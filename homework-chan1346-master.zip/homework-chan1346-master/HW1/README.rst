Homework 1
##########

:Name: Seungman Chang
:Term: Summer, 2017
