Homework 7
##########

:Name: John Von Neumann
:Term: Summer, 2017
