COSC2325 Homework Repository
############################

:Name: Seungman Chang
:Email: seungman.chang@g.austincc.edu

..  note::

    Obviously, you should change this name and email information.

The initial folders provided in this repository are where you will save your
homework submissions. They will be graded after something shows up in each one.

Template for student homework repo.

..  vim:ft=rst spell:
