Homework 2
##########

:Name: John Von Neumann
:Term: Summer, 2017
